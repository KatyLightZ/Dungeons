<template>

  <div class="panel">
    <div class="map-box">
      <div class="map">
        <div v-for="(item ,y) in gameMap" class="row">
          <smart-cover :src="'/img/floor/'+this.mapTheme+'/floor.png'" v-for="(zit,x) in item" class="cube">
            <div v-if="zit.visible" class="inner" @click="activeCube(zit,y,x)" :id="'monster'+y+'-'+x">
              <smart-image v-if="zit.role === cubeRole.ENTER " title="入口" src="/img/floor/door-enter-close.png"
                           class="inner-image"/>
              <smart-image v-else-if="zit.role === cubeRole.EXIT " title="出口"
                           :src="hero.key?'/img/floor/door-exit-open.png':'/img/floor/door-exit-close.png'"
                           class="inner-image"/>
              <smart-image v-else-if=" zit.monster" :title="zit.monster.info" :src="zit.monster.img"
                           :class="['inner-image' ]"/>
              <smart-image v-else-if="zit.goods" :title="zit.goods.info" :src="zit.goods.img" class="inner-image"/>
              <smart-image v-else-if="zit.key" :title="zit.key.info" :src="zit.key.img" class="inner-image"/>
              <smart-image v-if="zit.monster===0" src="/img/sys/monster-death-image.png" class="inner-image death"/>
              <div v-if="zit.goods===0" class="inner-image goods"></div>
              <div class="monster-control" v-if="zit.monster">
                <div class="atk">{{ $formatNumber(zit.monster.atk) }}</div>
                <div class="speed">{{ $formatNumber(zit.monster.speed) }}</div>
                <div class="health">{{ $formatNumber(zit.monster.health) }}</div>
              </div>
            </div>
            <smart-cover :src="'/img/floor/'+this.mapTheme+'/wall.png'" @click="zit.visible=checkCanClick(y,x);" v-else
                         :class="['stone',
        gameMap[y+1]?.[x]?.visible||
        gameMap[y-1]?.[x]?.visible||
        gameMap[y]?.[x+1]?.visible||
        gameMap[y]?.[x-1]?.visible ?'lighter':'' ]">
              <smart-cover src="/img/sys/ban.png"
                           v-if=" (gameMap[y+1]?.[x]?.visible&&gameMap[y+1]?.[x]?.monster)||
        (gameMap[y-1]?.[x]?.visible&&gameMap[y-1]?.[x]?.monster)||
       ( gameMap[y]?.[x+1]?.visible&&gameMap[y]?.[x+1]?.monster)||
        (gameMap[y]?.[x-1]?.visible&&gameMap[y]?.[x-1]?.monster )"
                           :class="['stone-ban']"></smart-cover>
            </smart-cover>
          </smart-cover>
        </div>
      </div>
    </div>
    <div class="hero">
      <h1>LEVEL {{ level }}</h1>
      <div class="row"> 玩家：【hero】</div>
      <div class="row"> Atk：{{ $formatNumber(hero.atk) }}数字长度：{{ hero.atk.toString().length }}</div>
      <div class="row"> health:{{ $formatNumber(hero.health) }}</div>
      <div class="row"> speed:{{ $formatNumber(hero.speed) }}</div>
      <div class="row"> 是否得到钥匙:{{ hero.key }}</div>
      <div>
        <smart-cover id="hero-avatar" src="/img/hero/Athena.webp"
                     :class="['hero-avatar',hero.ani.hurt?'hurt':'',]"></smart-cover>
      </div>
    </div>
  </div>
  <div style="display: none">
    <svg>
      <!--    <filter id="colorMeMatrixRed">-->
      <!--      <feColorMatrix in="SourceGraphic" operator="arithmetic"  type="matrix" values="1 1 1 1 0-->
      <!--				              0 0 0 0 0-->
      <!--				              0 0 0 0 0-->
      <!--				              0 0 0 0.4 0" />-->
      <!--    </filter>-->
      <filter id="colorMeMatrixRed">
        <feColorMatrix result="original" id="c1" type="matrix"
                       values="1.1 1.6 1.3 0.8 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix>
      </filter>
    </svg>
  </div>
</template>
<script>

import SmartImage from "@/components/smartImage";
import SmartCover from "@/components/smartCover";

const mapThemeRole = {
  FROZEN: "frozen",
  LAVA: "lava",
  FROST: "frost",
  HOLLOW: "hollow",
  MINE: "mine",
};
const mapThemeRoleArr = Object.keys(mapThemeRole);
const cubeRole = {
  NORMAL: 0,
  ENTER: 1,
  EXIT: 2,
  MONSTER: 3,
}
const KEYObject = {
  info: '钥匙',
  title: '钥匙',
  img: '/img/goods/key.png'
}
const skillActiveRole = {
  HEALTH: 1,
  ATK: 2,
  ImproveAttributes: 3,
};
const ImproveAttributesParams = {
  HEALTH: 1,
  ATK: 2,
  SPEED: 2,
}
const ImproveAttributesParamsTranslate = {
  [ImproveAttributesParams.HEALTH]: '恢复生命值',
  [ImproveAttributesParams.ATK]: '提升攻击力'
}
const getImproveAttributesTemp = (type, number) => {
  return ImproveAttributesParamsTranslate[type] + (number > 0 ? "+" + number : number);
}

function MakeImproveAttributesGoods(name, img, type, number) {
  return {
    title: name,
    ACTIVE: {
      type: type,
      params: number,
    },
    info: getImproveAttributesTemp(type, number),
    img: img
  }
}

const goodsMap = {
  APPLE: MakeImproveAttributesGoods('苹果', '/img/goods/apple.png', ImproveAttributesParams.HEALTH, 12),
  PEAR: MakeImproveAttributesGoods('梨子', '/img/goods/pear.png', ImproveAttributesParams.HEALTH, 12),
  MEAT: MakeImproveAttributesGoods('肉', '/img/goods/meat.png', ImproveAttributesParams.HEALTH, 30),
  SWORD: MakeImproveAttributesGoods('剑', '/img/goods/sword.png', ImproveAttributesParams.ATK, 3),
};
const goodsMapArr = Object.keys(goodsMap);

function MakeMonster(name, img, health, atk, speed) {
  return {
    info: name,
    title: name,
    img: img,
    health: health,
    atk: atk,
    speed: speed,
  }
}

const monsterMap = {
  DEMON: MakeMonster('恶魔', '/img/unit/monster-green.png', 30, 12, 3),
  SKULL: MakeMonster('骷髅头', '/img/unit/skull.png', 22, 12, 33),
  GHOST: MakeMonster('幽灵', '/img/unit/ghost.png', 22, 8, 112),
};
const monsterMapArr = Object.keys(monsterMap);
export default {
  name: "aA",
  components: {SmartCover, SmartImage,},
  data() {
    return {
      //Hero 玩家
      hero: {
        //传说中的数字
        atk: 111111111111111111,
        //9 007 199 254 740 991 16位数最高，附属也是
        // 9 * Math.pow(10*15)
        health: 111111111111111111,
        speed: 40,
        key: false,
        buff: [],
        ani: {
          hurt: false,
        },
      },
      //对象数组。x在最里面，
      mapTheme: mapThemeRole.FROZEN,
      gameMap: [],
      gameXLength: 25,
      gameYLength: 18,
      monsterNumber: 33,
      goodsNumber: 33,
      level: 1,

      cubeRole: cubeRole,
      enterObj: {
        x: 0,
        y: 0
      },
      keyObj: {
        x: 0,
        y: 0
      },
      exitObj: {
        x: 0,
        y: 0
      },
    }
  },
  watch: {
    'hero.health': {
      handler(n, o) {
        if (n > Math.pow(10, 9)) {
          this.hero.health = Infinity;
          this.$nextTick(() => {
            this.$texttag.warn({
              text: '生命值数字即将溢出，进入无限生命状态！！！',
              target: document.getElementById('hero-avatar'),
              cls: 'center',
              size: 40
            });
          })
        }
        let w = n - o;
        if (o > n) {
          if (o === undefined)
            return;
          this.$texttag.error({
            text: w,
            target: document.getElementById('hero-avatar'),
            cls: 'center',
            size: 60
          });
          if (this.hero.ani.hurt) {
            return;
          }
          this.hero.ani.hurt = setTimeout(() => {
            this.hero.ani.hurt = false;
          }, 300);
        } else {
          if (o === undefined)
            return;
          this.$texttag.success({
            text: "+" + w,
            target: document.getElementById('hero-avatar'),
            cls: 'center',
            size: 60
          });
        }
      },
      immediate: true,
    },
    'hero.atk': {
      handler(n, o) {
        if (n > Math.pow(10, 9)) {
          this.hero.atk = Infinity;
          this.$nextTick(() => {
            this.$texttag.warn({
              text: '攻击数字即将溢出，进入秒杀状态！！！',
              target: document.getElementById('hero-avatar'),
              cls: 'center',
              size: 40
            });
          })
        }
      },
      immediate: true,
    },


  },
  mounted() {
    this.init_game_map();
    this.init_hero();
  },
  methods: {
    init_hero() {
      this.hero.key = false;
    },
    activeCube(o, y, x) {
      console.log(o.monster)
      if (o.role === cubeRole.EXIT && this.hero.key) {
        alert('下一关');
        this.level++;

        /*
        *
        *
        * */
        this.init_game_map();
        this.init_hero();
        return;
      }
      if (o.monster) {
        this.battleMonster(o, y, x);
        return;
      }
      if (o.goods) {
        this.useGoods(o.goods);
        o.goods = 0;
        return;
      }
      if (o.key) {
        o.key = 0;
        this.hero.key = true;
        return;
      }
    },
    battleMonster(o, y, x) {
      if (o.monster.speed > this.hero.speed) {
        this.hero.health -= o.monster.atk;
        if (this.hero.health <= 0) {
          alert('你被打败');
          return;
        }
        o.monster.health -= this.hero.atk;
        if (o.monster.health <= 0) {
          o.monster = 0;
        }
      } else {
        o.monster.health -= this.hero.atk;
        if (o.monster.health <= 0) {
          o.monster = 0;
        } else {
          this.hero.health -= o.monster.atk;
        }
        if (this.hero.health <= 0) {
          alert('你被打败');
          return;
        }
      }
      if (this.hero.atk > 0) {
        this.$texttag.error({
          text: "-" + this.$formatNumber(this.hero.atk, true),
          target: document.getElementById('monster' + y + '-' + x),
          cls: 'center',
          size: 30
        });
      } else {
        this.$texttag.success({
          text: "+" + this.$formatNumber(this.hero.atk, true),
          target: document.getElementById('monster' + y + '-' + x),
          cls: 'center',
          size: 30
        });
      }

    },
    useGoods(o) {
      switch (o.ACTIVE.type) {
        case ImproveAttributesParams.HEALTH:
          this.hero.health += o.ACTIVE.params;
          break;
        case ImproveAttributesParams.ATK:
          this.hero.atk += o.ACTIVE.params;
          break;
        case ImproveAttributesParams.SPEED:
          this.hero.speed += o.ACTIVE.params;
          break;
      }
    },
    checkCanClick(y, x) {
      // for(let i=y-1;i<=y+1;i++){
      //   for(let ii=x-1;ii<=x+1;ii++){
      //     if(this.gameMap[i]?.[ii]?.visible){
      //       return true;
      //     }
      //   }
      // }
      // return false;
      if ((this.gameMap[y + 1]?.[x]?.visible && this.gameMap[y + 1]?.[x]?.monster) ||
          (this.gameMap[y - 1]?.[x]?.visible && this.gameMap[y - 1]?.[x]?.monster) ||
          (this.gameMap[y]?.[x + 1]?.visible && this.gameMap[y]?.[x + 1]?.monster) ||
          (this.gameMap[y]?.[x - 1]?.visible && this.gameMap[y]?.[x - 1]?.monster)) {
        return false;
      }
      return !!(this.gameMap[y + 1]?.[x]?.visible ||
          this.gameMap[y - 1]?.[x]?.visible ||
          this.gameMap[y]?.[x + 1]?.visible ||
          this.gameMap[y]?.[x - 1]?.visible);
    },
    init_game_map() {
      this.gameXLength=Math.floor(Math.random()*10)+5;
      this.gameYLength=Math.floor(Math.random()*20)+7;
      this.monsterNumber=(this.gameXLength*this.gameYLength)/4;
      this.goodsNumber=(this.gameXLength*this.gameYLength)/4;
      this.mapTheme = mapThemeRole[mapThemeRoleArr[Math.floor(mapThemeRoleArr.length * Math.random())]];
      let f = [];
      for (let yi = 0; yi < this.gameYLength; yi++) {
        let z = [];
        for (let xi = 0; xi < this.gameXLength; xi++) {
          z.push(
              {
                role: cubeRole.NORMAL,
                visible: false,
                x: xi,
                y: yi
              }
          )
        }
        f.push(z);
      }
      this.gameMap = f;
      this.setDoorEnter();
      this.setDoorExit();
      this.setKey();
      this.setGoods();
      this.setMonster();
    },
    setDoorEnter() {
      let x = 1 + Math.floor(Math.random() * (this.gameXLength - 1));
      let y = 1 + Math.floor(Math.random() * (this.gameYLength - 1));
      this.gameMap[y][x].role = cubeRole.ENTER;
      this.gameMap[y][x].visible = true;
      this.enterObj.x = x;
      this.enterObj.y = y;
    },

    setDoorExit() {
      let maxDisX = this.enterObj.x + 2;
      let minDisX = this.enterObj.x - 2;
      let maxDisY = this.enterObj.y + 2;
      let minDisY = this.enterObj.y - 2;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          !(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY)
      ));
      let y = Math.floor(datenMap.length * Math.random());
      let x = Math.floor(datenMap[y].length * Math.random());
      let o = datenMap[y][x];
      this.gameMap[o.y][o.x].role = cubeRole.EXIT;
      this.exitObj.x = o.x;
      this.exitObj.y = o.y;
    },
    setKey() {
      let maxDisX = this.enterObj.x + 2;
      let minDisX = this.enterObj.x - 2;
      let maxDisY = this.enterObj.y + 2;
      let minDisY = this.enterObj.y - 2;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          (!(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY))
          && !((zit.x === this.exitObj.x && zit.y === this.exitObj.y))
      ));
      let y = Math.floor(datenMap.length * Math.random());
      let x = Math.floor(datenMap[y].length * Math.random());
      let o = datenMap[y][x];
      this.gameMap[o.y][o.x].key = KEYObject;
      this.keyObj.x = o.x;
      this.keyObj.y = o.y;
    },
    setGoods() {
      let maxDisX = this.enterObj.x + 1;
      let minDisX = this.enterObj.x - 1;
      let maxDisY = this.enterObj.y + 1;
      let minDisY = this.enterObj.y - 1;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
              (!(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY))
              && !(
                  (zit.x === this.exitObj.x && zit.y === this.exitObj.y)
                  && (zit.x === this.keyObj.x && zit.y === this.keyObj.y)
              )
      ));
      for (let i = 0; i < this.goodsNumber; i++) {
        let y = Math.floor(datenMap.length * Math.random());
        let x = Math.floor(datenMap[y].length * Math.random());
        let o = datenMap[y][x];
        datenMap[y].splice(x, 1);
        if (datenMap[y].length < 1) {
          datenMap.splice(y, 1);
        }
        this.gameMap[o.y][o.x].goods = goodsMap[goodsMapArr[Math.floor(goodsMapArr.length * Math.random())]];
        this.keyObj.x = o.x;
        this.keyObj.y = o.y;
      }
    },
    setMonster() {
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          !(zit.x === this.enterObj.x && zit.y === this.enterObj.y) && (
              !(zit.x === this.exitObj.x && zit.y === this.exitObj.y))
      ));
      for (let i = 0; i < this.monsterNumber; i++) {
        let y = Math.floor(datenMap.length * Math.random());
        let x = Math.floor(datenMap[y].length * Math.random());
        let o = datenMap[y][x];
        datenMap[y].splice(x, 1);
        if (datenMap[y].length < 1) {
          datenMap.splice(y, 1);
        }
        let monster = JSON.parse(JSON.stringify(monsterMap[monsterMapArr[Math.floor(monsterMapArr.length * Math.random())]]));
        monster.atk += Math.floor(Math.random() * this.level / 2) + Math.floor(this.level / 3);
        this.gameMap[o.y][o.x].monster = monster;

        this.keyObj.x = o.x;
        this.keyObj.y = o.y;
      }
    },
    setExitKey() {
    },
    getArrayFromTo(
        from = 0,
        to = 10
    ) {
      let zrr = [];
      for (let i = from; i <= to; i++) {
        zrr.push(i);
      }
      return zrr;
    },
    exceptNumberArray(mutter = {
      from: 0,
      to: 10
    }, kind = {
      from: 0,
      to: 2
    }) {
      let zrr = [];
      for (let i = mutter.from; i <= mutter.to; i++) {
        if (!(kind.from <= i && i <= kind.to)) {
          zrr.push(i);
        }
      }
      return zrr;
    },
    exceptNumberArrayGiveArray(mutter = [], kind = {
      from: 0,
      to: 2
    }) {
      let zrr = [];
      for (let i = 0; i < mutter.length; i++) {
        if (!(kind.from <= mutter[i] && mutter[i] <= kind.to)) {
          zrr.push(mutter[i]);
        }
      }
      return zrr;
    },
  },
}
</script>
<style>


.hero-avatar {
  height: 300px;
  width: 300px;
}

@keyframes light {
  0% {
    filter: url(#colorMeMatrixRed);
    opacity: 1;
  }
  20% {
    opacity: 0.4;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }

}

.hero-avatar {
  position: relative;
}

.hero-avatar.hurt {
  animation: ease-in light .4s forwards;
}

.map .inner-image.hurt {
  animation: ease-in light .2s forwards;
}

@keyframes death {
  0% {
    opacity: 1;
  }
  15% {
    transform: translateY(-15px) translateX(-10px);
  }
  30% {
    transform: translateY(-16px) translateX(10px);

  }
  40% {
    transform: translateY(-30px) translateX(-40px);
  }
  70% {
    transform: translateY(-40px) translateX(40px);
  }
  100% {
    transform: translateY(-50px) translateX(0);
    opacity: 0;
  }

}

@keyframes lightZ {
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }

}

.map .inner-image.goods {
  animation: .4s linear lightZ;
  animation-iteration-count: 1;
  opacity: 0;
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  background-color: rgba(0, 0, 0, 0.6);
//box-shadow: inset 0 0   10px 5px grey;
}

.map .inner-image.death {
  animation: .6s linear death;
  animation-iteration-count: 1;
  opacity: 0;
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
}

.hero {
  color: white;
  border: 1px solid white;
  flex-shrink: 0;
  width: 400px;
}

.panel {
  box-sizing: border-box;
  padding: 20px;
  display: flex;
  width: 100vw;
  height: 100vh;
  overflow-x: hidden;
  overflow-y: auto;
}

.map {
  display: block;
  color: white;
  overflow-x: auto;
  overflow-y: auto;
  max-height:calc( 100vh - 40px);
  max-width:calc( 100vw - 440px);


}
.map-box {
  flex: 1;
}

.map .row {
  display: flex;
}
.map .stone {
  background-color: #FFFFFF44;
  filter: brightness(60%);
  flex: 1;
  position: relative;
  cursor: not-allowed;
}

.stone-ban {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  display: block;
  object-fit: contain;
  cursor: not-allowed;
}

.map .stone.lighter {
  filter: brightness(100%);
  cursor: pointer;
}

.map .inner {
  flex: 1;
  background-size: cover;
  position: relative;

}

.monster-control {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  justify-content: space-between;
  display: flex;
  font-size: 18px;
}

.monster-control .atk {
  background-color: #982f2f;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  color: white;
  height: 22px;
}

.monster-control .health {
  background-color: #98d721;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  color: white;
  height: 22px;
}

.monster-control .speed {
  background-color: #572c81;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  font-size: 12px;
  height: 22px;
  border-radius: 11px;
  color: white;
  align-items: center;
}

.map .inner-image {

  object-fit: contain;
  object-position: center;
  width: 100%;
  height: 100%;
  cursor: pointer;
}

.map .cube {
  height: 100px;
  width: 100px;
  flex-shrink: 0;
  font-size: 24px;
  display: flex;
  box-sizing: border-box;

}
</style>