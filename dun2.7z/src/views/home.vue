<template>


  <router-view   :key="$route.fullPath"/>

</template>
<script>

 export default {
  name: "homeA",

  data() {
    return {

    }
  },

  mounted() {

    // this.$refs.popSet.setMe(this.$refs.rightPup)
  }
}
</script>
