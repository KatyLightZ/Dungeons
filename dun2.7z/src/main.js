import {createApp} from 'vue'
import App from './App.vue'
import router from "@/router";

class KatyLightFadeSpan {
    constructor() {
    }

    info(param) {
        this.base('INFO', param)
    }

    warn(param) {
        this.base('WARN', param)
    }

    success(param) {
        this.base('SUCCESS', param)
    }

    error(param) {
        this.base('ERROR', param)
    }

    primary(param) {
        this.base('PRIMARY', param)
    }

    base(type, param) {
        let span = document.createElement('span');
        span.classList.add('kl-fade-span');
        if (typeof param.cls instanceof Array) {
            param.cls.forEach(c => span.classList.add(c));
        } else {
            span.classList.add(param.cls)
        }
        if (param.size) {
            span.style.fontSize = param.size + 'px';
        }
        span.innerText = param.text || '漂浮文字';
        switch (type) {
            case 'WARN':
                span.classList.add('warn')
                break
            case 'INFO':
                span.classList.add('info')
                break
            case 'SUCCESS':
                span.classList.add('success')
                break
            case 'ERROR':
                span.classList.add('error')
                break
            case 'PRIMARY':
                span.classList.add('primary')
                break
        }
        let x = [undefined, null].includes(param.x) ? '' : param.x;
        let y = [undefined, null].includes(param.y) ? '' : param.y;
        span.style.left = typeof x === 'number' ? x + 'px' : x;
        span.style.top = typeof y === 'number' ? y + 'px' : y;
        if (param.target) {
            if (['absolute', 'fixed', 'relative', 'sticky'].includes(param.target.style.position)) {
                span.style.position = 'absolute';
            }
            param.target.append(span);
        } else {
            span.style.position = 'fixed';
            document.body.append(span)
        }
        setTimeout(() => {
            // span.remove();
        }, 1500)
    }
}

/**
 * 单位之间的换算：
 *
 * 1、1DB=1024NB
 *
 * 2、1NB=1024BB
 *
 * 3、1BB=1024YB
 *
 * 4、1YB=1024ZB
 *
 * 5、1ZB=1024EB
 *
 * 6、1EB=1024PB
 *
 * 7、1PB=1024TB
 *
 * 8、1TB=1024GB
 *
 * 9、1GB=1024MB
 *
 * 10、1MB=1024KB
 *
 * 11、1KB=1024B*/
function formatNumber(n,vague) {
    if(n===Infinity||vague&&n===-Infinity){
        return "∞"
    }else if(n===-Infinity){
        return "-∞"
    }
    let s = n.toString() ;
    let v =s.length;
    let krr = [
        "K",
        "M",
        "G",
        "T",
        "P",
        "E",
        "Z",
        "Y",
        "B",
        "N",
        "D",
    ];
    let f = Math.floor((v - 1) / 3) - 1;


    if (f > -1) {
        if (f > krr.length-1) {
            //废除，太长的数字会导致计算机算不正确。
            //用切割字符串
            return  s.substr(0,3)  + krr[krr.length - 1]

            // return Math.floor(n * 100 / Math.pow(10, 3 * (krr.length - 1))) / 100 + krr[krr.length - 1];
        } else {
            return  s.substr(0,3)  + krr[krr.length - 1]
            // return Math.floor(n * 100 / Math.pow(10, (f + 1) * 3)) / 100 + krr[f];
        }
    }
    return n;
}

const app = createApp(App)
app.use(router)
app.config.globalProperties.$texttag = new KatyLightFadeSpan();
app.config.globalProperties.$formatNumber = formatNumber;
app.mount('body');

