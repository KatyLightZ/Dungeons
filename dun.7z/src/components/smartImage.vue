<template>
  <img :class="['smart-image',imgShow?'active':'']" alt="" :src="smartSrc"/>
</template>
<script>
export default {
  name: "smartImage",
  props: {src: {}, errorSrc:{default:  '/icon/404.jpg'}, },
  data() {
    return {
      imgShow: false, smartSrc: '',
      imageS: this.imageSuccess.bind(this),
      imageE: this.imageError.bind(this),
      image: null,
    }
  },
  watch: {
    // eslint-disable-next-line
    src(newVal,oldVal) {
      this.createHollowImage();
    },
  },
  mounted() {
    this.createHollowImage()

  },
  methods: {
    createHollowImage() {
      this.imgShow = false;
      if (this.image) {
        this.image.removeEventListener('load', this.imageS);
        this.image.removeEventListener('error', this.imageE);
        this.image = null;
      }
      this.image = document.createElement('img');
      this.image.src = this.src;
      this.image.addEventListener('load', this.imageS);
      this.image.addEventListener('error', this.imageE);
     },
    imageError() {
      this.imgShow = true;
      this.smartSrc = this.errorSrc
      if (this.image) {
        this.image.removeEventListener('load', this.imageS);
        this.image.removeEventListener('error', this.imageE);
        this.image = null;
      }
    },
    imageSuccess() {
      this.imgShow = true;
      this.smartSrc = this.src;
      if (this.image) {
        this.image.removeEventListener('load', this.imageS);
        this.image.removeEventListener('error', this.imageE);
        this.image = null;
      }
    }
  }
}
</script>
