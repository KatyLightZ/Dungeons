<template>
  <router-view class="page"
               :key="$route.meta.mutter"/>
</template>
<script>
// import { getCurrentInstance } from "vue"


export default {
  name: 'App',
  components: {},
  data() {
    return {
      pageKey: "",
      pastParam: {}
    }
  },

  mounted() {

  },
}
</script>
<style lang="scss">
@import "assets/scss/basic.scss";

</style>
