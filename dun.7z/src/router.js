// router.js
// import Vue from "Vue";
// import transitionRouter from "vue-transition-router";
import {createRouter, createWebHistory} from "vue-router";


const routes = [
    {
        path: '/home',
        name: 'home',
        meta: {transition: 3, mutter: "/home"},
        component: () => import("./views/home.vue"),
        children: [
            {path: '/home', redirect: '/home/index'},
            {
                path: "index",
                name: "homeIndex",
                meta: {
                    menu: 1,
                    transition: 3,
                    title: 'home',
                 },
                component: () => import("./views/home/index.vue"),
            },

        ]
    },
    {path: '/', redirect: '/home/index'},


];
let router = createRouter({
    history: createWebHistory(),
    routes: routes
})

// export default router;
export default router