<template>
  <svg>
    <!--    <filter id="colorMeMatrixRed">-->
    <!--      <feColorMatrix in="SourceGraphic" operator="arithmetic"  type="matrix" values="1 1 1 1 0-->
    <!--				              0 0 0 0 0-->
    <!--				              0 0 0 0 0-->
    <!--				              0 0 0 0.4 0" />-->
    <!--    </filter>-->
    <filter id="colorMeMatrixRed">
      <feColorMatrix result="original" id="c1" type="matrix"
                     values="1.1 1.6 1.3 0.8 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"></feColorMatrix>
    </filter>
  </svg>

  <div class="panel">
    <div class="map">
      <div v-for="(item ,y) in gameMap" class="row">
        <smart-cover :src="'/img/floor/'+this.mapTheme+'/floor.png'" v-for="(zit,x) in item" class="cube">
          <div v-if="zit.visible" class="inner" @click="activeCube(zit)">
            <smart-image v-if="zit.role === cubeRole.ENTER " title="入口" src="/img/floor/door-enter-close.png"
                         class="inner-image"/>
            <smart-image v-else-if="zit.role === cubeRole.EXIT " title="出口"
                         :src="hero.key?'/img/floor/door-exit-open.png':'/img/floor/door-exit-close.png'"
                         class="inner-image"/>
            <smart-image v-else-if=" zit.monster" :title="zit.monster.info" :src="zit.monster.img"
                         :class="['inner-image',zit.monster.hurt?'hurt':'']"/>
            <smart-image v-else-if=" zit.goods" :title="zit.goods.info" :src="zit.goods.img" class="inner-image"/>
            <smart-image v-else-if=" zit.key" :title="zit.key.info" :src="zit.key.img" class="inner-image"/>
            <smart-image v-if="zit.monster===0" src="/img/sys/monster-death-image.png" class="inner-image death"/>
            <div v-if="zit.goods===0" class="inner-image goods"></div>
            <div class="monster-control" v-if="zit.monster">
              <div class="atk">{{ zit.monster.atk }}</div>
              <div class="speed">{{ zit.monster.speed }}</div>
              <div class="health">{{ zit.monster.health }}</div>
            </div>
          </div>
          <smart-cover :src="'/img/floor/'+this.mapTheme+'/wall.png'" @click="zit.visible=checkCanClick(y,x);" v-else
                       :class="['stone',
        gameMap[y+1]?.[x]?.visible||
        gameMap[y-1]?.[x]?.visible||
        gameMap[y]?.[x+1]?.visible||
        gameMap[y]?.[x-1]?.visible ?'lighter':'' ]">
            <smart-cover src="/img/sys/ban.png"
                         v-if=" (gameMap[y+1]?.[x]?.visible&&gameMap[y+1]?.[x]?.monster)||
        (gameMap[y-1]?.[x]?.visible&&gameMap[y-1]?.[x]?.monster)||
       ( gameMap[y]?.[x+1]?.visible&&gameMap[y]?.[x+1]?.monster)||
        (gameMap[y]?.[x-1]?.visible&&gameMap[y]?.[x-1]?.monster )"
                         :class="['stone-ban']"></smart-cover>
          </smart-cover>
        </smart-cover>
      </div>
    </div>
    <div class="hero">
      <h1>LEVEL {{ level }}</h1>
      <div class="row"> 玩家：【hero】</div>
      <div class="row"> Atk：{{ hero.atk }}</div>
      <div class="row"> health:{{ hero.health }}</div>
      <div class="row"> speed:{{ hero.speed }}</div>
      <div class="row"> 是否得到钥匙:{{ hero.key }}</div>
      <div>
        <smart-cover src="/img/hero/Athena.webp" :class="['hero-avatar',hero.ani.hurt?'hurt':'',]"></smart-cover>
      </div>
    </div>
  </div>
</template>
<script>

import SmartImage from "@/components/smartImage";
import SmartCover from "@/components/smartCover";

const mapThemeRole = {
  FROZEN: "frozen",
  LAVA: "lava",
  FROST: "frost",
  HOLLOW: "hollow",
  MINE: "mine",
};
const mapThemeRoleArr = Object.keys(mapThemeRole);
const cubeRole = {
  NORMAL: 0,
  ENTER: 1,
  EXIT: 2,
  MONSTER: 3,
}
const KEYObject = {
  info: '钥匙',
  title: '钥匙',
  img: '/img/goods/key.png'
}
const skillActiveRole = {
  HEALTH: 1,
  ATK: 2,
  ImproveAttributes: 3,
};
const ImproveAttributesParams = {
  HEALTH: 1,
  ATK: 2,
  SPEED: 2,
}
const ImproveAttributesParamsTranslate = {
  [ImproveAttributesParams.HEALTH]: '恢复生命值',
  [ImproveAttributesParams.ATK]: '提升攻击力'
}
const getImproveAttributesTemp = (type, number) => {
  return ImproveAttributesParamsTranslate[type] + (number > 0 ? "+" + number : number);
}

function MakeImproveAttributesGoods(name, img, type, number) {
  return {
    title: name,
    ACTIVE: {
      type: type,
      params: number,
    },
    info: getImproveAttributesTemp(type, number),
    img: img
  }
}

const goodsMap = {
  APPLE: MakeImproveAttributesGoods('苹果', '/img/goods/apple.png', ImproveAttributesParams.HEALTH, 12),
  PEAR: MakeImproveAttributesGoods('梨子', '/img/goods/pear.png', ImproveAttributesParams.HEALTH, 12),
  MEAT: MakeImproveAttributesGoods('肉', '/img/goods/meat.png', ImproveAttributesParams.HEALTH, 30),
  SWORD: MakeImproveAttributesGoods('剑', '/img/goods/sword.png', ImproveAttributesParams.ATK, 3),
};
const goodsMapArr = Object.keys(goodsMap);

function MakeMonster(name, img, health, atk, speed) {
  return {
    info: name,
    title: name,
    img: img,
    health: health,
    atk: atk,
    speed: speed,
  }
}

const monsterMap = {
  DEMON: MakeMonster('恶魔', '/img/unit/monster-green.png', 30, 12, 3),
  SKULL: MakeMonster('骷髅头', '/img/unit/skull.png', 22, 12, 33),
  GHOST: MakeMonster('幽灵', '/img/unit/ghost.png', 22, 8, 112),
};
const monsterMapArr = Object.keys(monsterMap);
export default {
  name: "aA",
  components: {SmartCover, SmartImage,},
  data() {
    return {
      //Hero 玩家
      hero: {
        atk: 12,
        health: 191,
        speed: 40,
        key: false,
        buff: [],
        ani: {
          hurt: false,
        },
      },
      //对象数组。x在最里面，
      mapTheme: mapThemeRole.FROZEN,
      gameMap: [],
      gameXLength: 5,
      gameYLength: 8,
      level: 1,
      monsterNumber: 10,
      goodsNumber: 10,
      cubeRole: cubeRole,
      enterObj: {
        x: 0,
        y: 0
      },
      keyObj: {
        x: 0,
        y: 0
      },
      exitObj: {
        x: 0,
        y: 0
      },
    }
  },
  watch: {
    'hero.health': function (n, o) {
      if (o > n) {
        console.log('受害')
        if (this.hero.ani.hurt) {
          return;
        }
        this.hero.ani.hurt = setTimeout(() => {
          this.hero.ani.hurt = false;
        }, 300);

      } else {
        console.log('治疗')
      }
    }
  },
  mounted() {
    this.init_game_map();
    this.init_hero();
  },
  methods: {
    init_hero() {
      this.hero.key = false;
    },
    activeCube(o) {
      if (o.role === cubeRole.EXIT && this.hero.key) {
        alert('下一关');
        this.level++;
        this.mapTheme = mapThemeRole.LAVA;
        this.init_game_map();
        this.init_hero();
        return;
      }
      if (o.monster) {
        this.battleMonster(o);
        return;
      }
      if (o.goods) {
        this.useGoods(o.goods);
        o.goods = 0;
        return;
      }
      if (o.key) {
        o.key = 0;
        this.hero.key = true;
        return;
      }
    },
    battleMonster(o) {
      if (o.monster.speed > this.hero.speed) {
        this.hero.health -= o.monster.atk;
        if (this.hero.health <= 0) {
          alert('你被打败');
          return;
        }
        o.monster.health -= this.hero.atk;
        if (o.monster.health <= 0) {
          o.monster = 0;
        } else {
          if (!o.monster.hurt) {
            o.monster.hurt = setTimeout(() => {
              o.monster ? o.monster.hurt = false : '';
            }, 100);
          }
        }
      } else {
        o.monster.health -= this.hero.atk;
        if (o.monster.health <= 0) {
          o.monster = 0;
          return;
        } else {
          if (!o.monster.hurt) {
            o.monster.hurt = setTimeout(() => {
              o.monster ? o.monster.hurt = false : '';
            }, 100);
          }
        }
        this.hero.health -= o.monster.atk;
        if (this.hero.health <= 0) {
          alert('你被打败');
        }
      }

    },
    useGoods(o) {
      switch (o.ACTIVE.type) {
        case ImproveAttributesParams.HEALTH:
          this.hero.health += o.ACTIVE.params;
          break;
        case ImproveAttributesParams.ATK:
          this.hero.atk += o.ACTIVE.params;
          break;
        case ImproveAttributesParams.SPEED:
          this.hero.speed += o.ACTIVE.params;
          break;
      }
    },
    checkCanClick(y, x) {
      // for(let i=y-1;i<=y+1;i++){
      //   for(let ii=x-1;ii<=x+1;ii++){
      //     if(this.gameMap[i]?.[ii]?.visible){
      //       return true;
      //     }
      //   }
      // }
      // return false;
      if ((this.gameMap[y + 1]?.[x]?.visible && this.gameMap[y + 1]?.[x]?.monster) ||
          (this.gameMap[y - 1]?.[x]?.visible && this.gameMap[y - 1]?.[x]?.monster) ||
          (this.gameMap[y]?.[x + 1]?.visible && this.gameMap[y]?.[x + 1]?.monster) ||
          (this.gameMap[y]?.[x - 1]?.visible && this.gameMap[y]?.[x - 1]?.monster)) {
        return false;
      }
      return !!(this.gameMap[y + 1]?.[x]?.visible ||
          this.gameMap[y - 1]?.[x]?.visible ||
          this.gameMap[y]?.[x + 1]?.visible ||
          this.gameMap[y]?.[x - 1]?.visible);
    },
    init_game_map() {
      this.mapTheme = mapThemeRole[mapThemeRoleArr[Math.floor(mapThemeRoleArr.length * Math.random())]];
      let f = [];
      for (let yi = 0; yi < this.gameYLength; yi++) {
        let z = [];
        for (let xi = 0; xi < this.gameXLength; xi++) {
          z.push(
              {
                role: cubeRole.NORMAL,
                visible: false,
                x: xi,
                y: yi
              }
          )
        }
        f.push(z);
      }
      this.gameMap = f;
      this.setDoorEnter();
      this.setDoorExit();
      this.setKey();
      this.setGoods();
      this.setMonster();
    },
    setDoorEnter() {
      let x = 1 + Math.floor(Math.random() * (this.gameXLength - 1));
      let y = 1 + Math.floor(Math.random() * (this.gameYLength - 1));
      this.gameMap[y][x].role = cubeRole.ENTER;
      this.gameMap[y][x].visible = true;
      this.enterObj.x = x;
      this.enterObj.y = y;
    },
    setDoorExit() {
      let maxDisX = this.enterObj.x + 2;
      let minDisX = this.enterObj.x - 2;
      let maxDisY = this.enterObj.y + 2;
      let minDisY = this.enterObj.y - 2;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          !(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY)
      ));
      let y = Math.floor(datenMap.length * Math.random());
      let x = Math.floor(datenMap[y].length * Math.random());
      let o = datenMap[y][x];
      this.gameMap[o.y][o.x].role = cubeRole.EXIT;
      this.exitObj.x = o.x;
      this.exitObj.y = o.y;
    },
    setKey() {
      let maxDisX = this.enterObj.x + 2;
      let minDisX = this.enterObj.x - 2;
      let maxDisY = this.enterObj.y + 2;
      let minDisY = this.enterObj.y - 2;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          (!(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY))
          && !((zit.x === this.exitObj.x && zit.y === this.exitObj.y))
      ));
      let y = Math.floor(datenMap.length * Math.random());
      let x = Math.floor(datenMap[y].length * Math.random());
      let o = datenMap[y][x];
      this.gameMap[o.y][o.x].key = KEYObject;
      this.keyObj.x = o.x;
      this.keyObj.y = o.y;
    },
    setGoods() {
      let maxDisX = this.enterObj.x + 1;
      let minDisX = this.enterObj.x - 1;
      let maxDisY = this.enterObj.y + 1;
      let minDisY = this.enterObj.y - 1;
      let datenMap = this.gameMap.map(item => item.filter(zit =>
              (!(zit.x < maxDisX && zit.x > minDisX && zit.y < maxDisY && zit.y > minDisY))
              && !(
                  (zit.x === this.exitObj.x && zit.y === this.exitObj.y)
                  && (zit.x === this.keyObj.x && zit.y === this.keyObj.y)
              )
      ));
      for (let i = 0; i < this.goodsNumber; i++) {
        let y = Math.floor(datenMap.length * Math.random());
        let x = Math.floor(datenMap[y].length * Math.random());
        let o = datenMap[y][x];
        datenMap[y].splice(x, 1);
        if (datenMap[y].length < 1) {
          datenMap.splice(y, 1);
        }
        this.gameMap[o.y][o.x].goods = goodsMap[goodsMapArr[Math.floor(goodsMapArr.length * Math.random())]];
        this.keyObj.x = o.x;
        this.keyObj.y = o.y;
      }
    },
    setMonster() {
      let datenMap = this.gameMap.map(item => item.filter(zit =>
          !(zit.x === this.enterObj.x && zit.y === this.enterObj.y) && (
              !(zit.x === this.exitObj.x && zit.y === this.exitObj.y))
      ));
      for (let i = 0; i < this.monsterNumber; i++) {
        let y = Math.floor(datenMap.length * Math.random());
        let x = Math.floor(datenMap[y].length * Math.random());
        let o = datenMap[y][x];
        datenMap[y].splice(x, 1);
        if (datenMap[y].length < 1) {
          datenMap.splice(y, 1);
        }
        let monster = JSON.parse(JSON.stringify(monsterMap[monsterMapArr[Math.floor(monsterMapArr.length * Math.random())]]));
        monster.atk += Math.floor(Math.random() * this.level / 2) + Math.floor(this.level / 3);
        this.gameMap[o.y][o.x].monster = monster;

        this.keyObj.x = o.x;
        this.keyObj.y = o.y;
      }
    },
    setExitKey() {
    },
    getArrayFromTo(
        from = 0,
        to = 10
    ) {
      let zrr = [];
      for (let i = from; i <= to; i++) {
        zrr.push(i);
      }
      return zrr;
    },
    exceptNumberArray(mutter = {
      from: 0,
      to: 10
    }, kind = {
      from: 0,
      to: 2
    }) {
      let zrr = [];
      for (let i = mutter.from; i <= mutter.to; i++) {
        if (!(kind.from <= i && i <= kind.to)) {
          zrr.push(i);
        }
      }
      return zrr;
    },
    exceptNumberArrayGiveArray(mutter = [], kind = {
      from: 0,
      to: 2
    }) {
      let zrr = [];
      for (let i = 0; i < mutter.length; i++) {
        if (!(kind.from <= mutter[i] && mutter[i] <= kind.to)) {
          zrr.push(mutter[i]);
        }
      }
      return zrr;
    },
  },
}
</script>
<style>
.panel {
  display: flex;
}

.hero-avatar {
  height: 300px;
  width: 300px;
}

@keyframes light {
  0% {
    filter: url(#colorMeMatrixRed);
    opacity: 1;
  }
  20% {
    opacity: 0.4;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }

}

.hero-avatar.hurt {
  animation: ease-in light .4s forwards;
}

.map .inner-image.hurt {
  animation: ease-in light .2s forwards;
}

@keyframes death {
  0% {
    opacity: 1;
  }
  15% {
    transform: translateY(-15px) translateX(-10px);
  }
  30% {
    transform: translateY(-16px) translateX(10px);

  }
  40% {
    transform: translateY(-30px) translateX(-40px);
  }
  70% {
    transform: translateY(-40px) translateX(40px);
  }
  100% {
    transform: translateY(-50px) translateX(0);
    opacity: 0;
  }

}
@keyframes lightZ {
  0% {
     opacity: 1;
  }

  100% {
    opacity: 0;
  }

}

.map .inner-image.goods {
  animation: .4s linear lightZ;
  animation-iteration-count: 1;
  opacity: 0;
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  background-color: rgba(0,0,0,0.6);
  //box-shadow: inset 0 0   10px 5px grey;
}

.map .inner-image.death {
  animation: .6s linear death;
  animation-iteration-count: 1;
  opacity: 0;
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
}

.hero {
  flex: 1;
  color: white;
  border: 1px solid white;
  margin: 40px 20px;
}

.map {
  display: block;
  padding: 0 30px 30px 0;
  color: white;
}

.map .row {
  display: flex;
}

.map .stone {
  background-color: #FFFFFF44;
  filter: brightness(60%);
  flex: 1;
  position: relative;
  cursor: not-allowed;
}

.stone-ban {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  top: 0;
  display: block;
  object-fit: contain;
  cursor: not-allowed;
}

.map .stone.lighter {
  filter: brightness(100%);
  cursor: pointer;
}

.map .inner {
  flex: 1;
  background-size: cover;
  position: relative;

}

.monster-control {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  justify-content: space-between;
  display: flex;
  font-size: 18px;
}

.monster-control .atk {
  background-color: #982f2f;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  color: white;
  height: 22px;
}

.monster-control .health {
  background-color: #98d721;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  color: white;
  height: 22px;
}

.monster-control .speed {
  background-color: #572c81;
  display: inline-flex;
  border-radius: 2px;
  padding: 4px;
  font-size: 12px;
  height: 22px;
  border-radius: 11px;
  color: white;
  align-items: center;
}

.map .inner-image {

  object-fit: contain;
  object-position: center;
  width: 100%;
  height: 100%;
  cursor: pointer;
}

.map .cube {
  height: 100px;
  width: 100px;
  flex-shrink: 0;
  font-size: 24px;
  display: flex;
  box-sizing: border-box;

}
</style>